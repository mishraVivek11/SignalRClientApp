﻿using System;
using System.IO;
using System.Threading.Tasks;
using SignalRClient.DataAccess;
using SignalRClient.Service;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace SignalRClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Initializing client");     
            
            ConfigureAndActivate();

            Console.ReadLine();
        }

        private static void ConfigureAndActivate()
        {
            IConfigurationBuilder builder = new ConfigurationBuilder();
            builder.SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            var host = Host.CreateDefaultBuilder()
                .ConfigureServices((context, services) =>
                {
                    services.AddTransient<IRepository, Repository>();
                    services.AddTransient<ISignalRClientService, SignalRClientService>();                    
                })
                .Build();

            var service = ActivatorUtilities.GetServiceOrCreateInstance<ISignalRClientService>(host.Services);
            service.ConfigureClient();
        }
    }
}
