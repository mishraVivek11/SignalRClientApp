﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SignalRClient.Model
{
    public class Message
    {
        public long timestamp { get; set; }
        public string type { get; set; }

        public Guid id { get; set; }
        public SensorData data { get; set; }
    }

    public class SensorData
    {
        public decimal? sensor1 { get; set; }
        public decimal? sensor2 { get; set; }
        public decimal? sensor3 { get; set; }
        public string sensor4 { get; set; }
        public decimal? sensor5 { get; set; }
        public decimal? sensor6 { get; set; }
        public string sensor7 { get; set; }

    }
}
