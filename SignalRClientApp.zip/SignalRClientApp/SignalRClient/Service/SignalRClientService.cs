﻿using System;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SignalRClient.DataAccess;
using SignalRClient.Model;

namespace SignalRClient.Service
{
    public class SignalRClientService :ISignalRClientService
    {
        private readonly IConfiguration configuration;
        private readonly IRepository repository;

        public SignalRClientService(IConfiguration configuration, IRepository repository)
        {
            this.configuration = configuration;
            this.repository = repository;
        }
        public void ConfigureClient()
        {
            var hubUrl = configuration.GetSection("hubUrl").Value;
            var connection = new HubConnectionBuilder()
                 .WithUrl(hubUrl)
                 .AddJsonProtocol(options =>
                 {
                     options.PayloadSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
                 })
                 .ConfigureLogging(logging =>
                 {
                     logging.AddConsole();
                     logging.SetMinimumLevel(LogLevel.Debug);
                 })
                 .Build();

            connection.On<Message>("ReceiveMessage", async (message) => await this.repository.ProcessMessageAsync(message).ConfigureAwait(false));

            connection.On("ShutdownClient", async () => { await connection.StopAsync(); Environment.Exit(0);});
        }
    }
}
