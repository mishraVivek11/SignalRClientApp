﻿namespace SignalRClient.Service
{
    public interface ISignalRClientService
    {
        void ConfigureClient();
    }
}