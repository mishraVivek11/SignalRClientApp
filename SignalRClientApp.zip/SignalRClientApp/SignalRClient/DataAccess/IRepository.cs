﻿using System.Threading.Tasks;
using SignalRClient.Model;

namespace SignalRClient.DataAccess
{
    public interface IRepository
    {
        Task ProcessMessageAsync(Message message);
    }
}