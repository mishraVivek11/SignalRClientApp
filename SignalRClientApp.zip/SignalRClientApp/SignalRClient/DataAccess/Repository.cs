﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Npgsql;
using SignalRClient.Model;

namespace SignalRClient.DataAccess
{
    public class Repository : IRepository
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<Repository> logger;

        public Repository(IConfiguration configuration,ILogger<Repository> logger)
        {
            this.configuration = configuration;
            this.logger = logger;
        }

        public async Task ProcessMessageAsync(Message message)
        {
            var queryParams = this.GetQueryParameters(message);
            await this.WriteMessageToDbAsync(queryParams).ConfigureAwait(false);
        }

        private async Task WriteMessageToDbAsync(QueryParams queryParams)
        {
            try
            {
                using (var connection = await this.GetDbConnectionAsync().ConfigureAwait(false))
                {
                    var sql = $"INSERT INTO [{queryParams.TableName}] ({queryParams.ColumnNames}) VALUES({queryParams.ColumnMapping})";
                    IEnumerable<int> id = await connection.QueryAsync<int>(sql, queryParams.ColumnValueMap, commandType: CommandType.Text).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
            }
        }

        public async Task<IDbConnection> GetDbConnectionAsync()
        {
            var connection = new NpgsqlConnection(this.configuration.GetConnectionString("DefaultConnection"));
            await connection.OpenAsync().ConfigureAwait(false);
            return connection;
        }


        private QueryParams GetQueryParameters(Message message)
        {
            StringBuilder columnNames = new StringBuilder();
            StringBuilder columnMapping = new StringBuilder();
            Dictionary<string, object> columnValueMap = new Dictionary<string, object>();

            columnNames.Append($"{nameof(message.timestamp)}, {nameof(message.id)}");
            columnMapping.Append($"@{nameof(message.timestamp)}, @{nameof(message.id)}");

            columnValueMap.Add(nameof(message.timestamp), message.timestamp);
            columnValueMap.Add(nameof(message.id), message.id);

            foreach (var property in typeof(SensorData).GetProperties())
            {
                var propVal = typeof(SensorData).GetProperty(property.Name).GetValue(message.data, null);
                if (propVal != null)
                {
                    columnNames.Append($",{property.Name}");
                    columnMapping.Append($", @{property.Name}");
                    columnValueMap.Add(property.Name, propVal);
                }
            }
            return new QueryParams() { ColumnNames = columnNames.ToString(), ColumnMapping = columnMapping.ToString(), ColumnValueMap = columnValueMap, TableName = message.type };
        }

    }   
}
