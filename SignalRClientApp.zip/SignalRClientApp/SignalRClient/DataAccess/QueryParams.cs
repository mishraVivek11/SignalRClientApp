﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SignalRClient.DataAccess
{
    public class QueryParams
    {
        public string ColumnNames { get; set; }
        public string ColumnMapping { get; set; }
        public Dictionary<string, object> ColumnValueMap { get; set; }
        public string TableName { get; set; }

    }
}
